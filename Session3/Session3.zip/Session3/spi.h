//
// spi.h
//
// Created: 07.04.2016
// Author: Asbjørn Espe
//

// Function for initializing SPI
void SPI_MasterInit();

// Function for transmitting SPI data
void SPI_MasterTransmit(char cData);
